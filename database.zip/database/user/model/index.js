// mongoose模块是第三方模块，当前文件目录下没有这个模块，但是当前目录的node_modules文件夹下有mongoose模块，所以模块可以引用成功
// 在user.js和index.js中都引用了mongoose第三方模块，不会造成性能浪费，因为引入一次之后下一次就是从缓存中拿了
const mongoose = require('mongoose');
// console.log(mongoose));
// 数据库连接 27017是mongodb数据库的默认端口，可以不写，不写默认就是这个端口
mongoose.connect('mongodb://localhost/playground', { useNewUrlParser: true ,useUnifiedTopology: true })
	.then(() => console.log('数据库连接成功'))
	.catch(() => console.log('数据库连接失败'));