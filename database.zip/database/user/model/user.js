// mongoose模块是第三方模块，当前文件目录下没有这个模块，但是当前目录的node_modules文件夹下有mongoose模块，所以模块可以引用成功
// 在user.js和index.js中都引用了mongoose第三方模块，不会造成性能浪费，因为引入一次之后下一次就是从缓存中拿了
const mongoose = require('mongoose');
// 创建用户集合规则
const userSchema = new mongoose.Schema({
	name: {
		type: String,
		required: true,
		minlength: 2,
		maxlength: 20
	},
	age: {
		type: Number,
		min: 18,
		max: 80
	},
	password: String,
	email: String,
	hobbies: [ String ]
});

// 创建集合 返回集合构造函数
const User = mongoose.model('User', userSchema);

module.exports = User;